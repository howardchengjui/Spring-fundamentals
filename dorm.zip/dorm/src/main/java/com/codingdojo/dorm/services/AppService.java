package com.codingdojo.dorm.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.dorm.models.Course;
import com.codingdojo.dorm.models.Dorm;
import com.codingdojo.dorm.models.Student;
import com.codingdojo.dorm.repositories.ClassRepository;
import com.codingdojo.dorm.repositories.DormRepository;
import com.codingdojo.dorm.repositories.StudentRepository;

@Service
public class AppService {
	@Autowired
	DormRepository dormRepo;
	@Autowired
	StudentRepository studentRepo;
	@Autowired
	ClassRepository classRepo;
	
	public void createDorm(@Valid Dorm dorm) {
		// TODO Auto-generated method stub
		dormRepo.save(dorm);
	}

	public void createStudent(@Valid Student student) {
		// TODO Auto-generated method stub
		studentRepo.save(student);
	}

	public List<Dorm> getAllDorms() {
		// TODO Auto-generated method stub
		return dormRepo.findAll();
	}

	public Dorm getDorm(Long id) {
		// TODO Auto-generated method stub
		Optional<Dorm> optDorm = dormRepo.findById(id);
		if(optDorm.isPresent()) {
			return optDorm.get();
		}else {
			return null;
		}
	}

	public Student getStudent(Long id) {
		// TODO Auto-generated method stub
		Optional<Student> optStudent = studentRepo.findById(id);
		if(optStudent.isPresent()) {
			return optStudent.get();
		}else {
			return null;
		}
	}

	public void createCourse(@Valid Course course) {
		// TODO Auto-generated method stub
		classRepo.save(course);
	}
	
	
}
