package com.codingdojo.dorm.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.dorm.models.Course;

@Repository
public interface ClassRepository extends CrudRepository<Course,Long>{

}
