package com.codingdojo.dorm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DormApplication {

	public static void main(String[] args) {
		SpringApplication.run(DormApplication.class, args);
	}

}
